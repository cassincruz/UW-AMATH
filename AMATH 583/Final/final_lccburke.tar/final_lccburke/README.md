# AMATH 583 Final
Author: Lucas Cassin Cruz Burke
Date: June 9, 2023

## Solutions
- Solutions for problems 1-4 are given in PDF writeup at /Writeup/583_Final.pdf
- Solutions for problems 5-11 can be found in the corresponding folders in /Code/, e.g. /Code/P5. 
