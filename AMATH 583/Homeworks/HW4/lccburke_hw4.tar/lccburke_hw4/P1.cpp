#include <iostream>
#include <fstream>
#include <vector>
#include <chrono>
#include <random>

using namespace std;

// Function to generate a square matrix of dimension dim.
vector<double> generateMatrix(int dim) {
    // Create a random number generator
    mt19937_64 rng(std::random_device{}());
    uniform_real_distribution<double> dist(0.0, 1.0);

    // Create the matrix and fill it with random values
    std::vector<double> matrix(dim * dim);
    for (int i = 0; i < dim * dim; i++)
    {
        matrix[i] = dist(rng);
    }
    return matrix;
}

// Function to write a matrix to a binary file.
void writeMatrix(const vector<double>& matrix, int dim, const string& filename) {
    ofstream out(filename, ios::binary);
    if (!out) {
        cerr << "Failed to open file: " << filename << endl;
        return;
    }
    out.write(reinterpret_cast<const char*>(&matrix[0]), dim * dim * sizeof(double));
    out.close();
}

// Function to read a matrix from a binary file.
vector<double> readMatrix(int dim, const string& filename) {
    vector<double> matrix(dim * dim);
    ifstream input(filename, ios::binary);
    if (!input) {
        cerr << "Failed to open file: " << filename << endl;
        return matrix;
    }
    input.read(reinterpret_cast<char*>(&matrix[0]), dim * dim * sizeof(double));
    input.close();
    return matrix;
}

int main() {
    vector<int> dimensions = {32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384};
    for (int dim : dimensions) {
        string filename = "matrix_" + to_string(dim) + ".bin";
        vector<double> matrix = generateMatrix(dim);

        auto start = chrono::high_resolution_clock::now();
        writeMatrix(matrix, dim, filename);
        auto end = chrono::high_resolution_clock::now();
        double writeTime = chrono::duration<double, std::milli>(end - start).count();
        cout << "Write time for dim = " << dim << ": " << writeTime << "ms" << endl;

        start = chrono::high_resolution_clock::now();
        matrix = readMatrix(dim, filename);
        end = chrono::high_resolution_clock::now();
        double readTime = chrono::duration<double, std::milli>(end - start).count();
        cout << "Read time for dim = " << dim << ": " << readTime << "ms" << endl;
    }

    return 0;
}
