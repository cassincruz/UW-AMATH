#include <iostream>
#include <cmath>
#include <vector>
#include <thread>
#include <chrono>

using namespace std;

// Function definition
double f(double x) {
    return log(x) - (1.0 / 8.0) * x * x;
}

// Derivative of function f
double f_prime(double x) {
    return 1.0 / x - x / 4.0;
}

// Function to compute length of the graph
double length(double a, double b, int n) {
    double h = (b - a) / n;
    double sum = 0.0;
    for (int i = 0; i < n; ++i) {
        double x = a + i * h;
        double y = f_prime(x);
        sum += sqrt(1 + y * y);
    }
    return sum * h;
}

// Function to compute length of the graph in parallel
void parallel_length(double a, double b, int n, int num_threads, double& result) {
    double h = (b - a) / n;
    vector<double> partial_sums(num_threads, 0.0);
    vector<thread> threads;

    for (int t = 0; t < num_threads; ++t) {
        threads.push_back(thread([&, t]() {
            int start = t * (n / num_threads);
            int end = (t == num_threads - 1) ? n : (t + 1) * (n / num_threads);

            for (int i = start; i < end; ++i) {
                double x = a + i * h;
                double y = f_prime(x);
                partial_sums[t] += sqrt(1 + y * y);
            }
        }));
    }

    for (thread& t : threads) {
        t.join();
    }

    result = 0.0;
    for (double sum : partial_sums) {
        result += sum;
    }
    result *= h;
}

// Evaluates function for given number of points and threads
int evaluate(int num_points, int num_threads) {
    double a = 1.0;
    double b = 6.0;

    auto start = chrono::high_resolution_clock::now();
    double result;
    parallel_length(a, b, num_points, num_threads, result);
    auto end = chrono::high_resolution_clock::now();

    double analytical_length = 35.0 / 8.0 + log(6);
    double error = abs(analytical_length - result);
    double elapsed = chrono::duration<double>(end - start).count();

    cout << num_points << "\t" << num_threads << "\t" << elapsed << "\t" << error << endl;

    return 0;
}

int main() {
    // Output the headers for the columns
    cout << "NumPoints\tNumThreads\tElapsedTime\tError" << endl;

    // Loop over the number of threads for the strong scaling efficiency plot
    int num_points = 1e8;
    for (int num_threads = 1; num_threads <= 6; ++num_threads) {
        evaluate(num_points, num_threads);
    }

    // Loop over the number of partition points for the numerical error plot
    int num_threads = 6;
    for (int num_points = 10; num_points <= 1e6; num_points *= 10) {
        evaluate(num_points, num_threads);
    }

    return 0;
}



