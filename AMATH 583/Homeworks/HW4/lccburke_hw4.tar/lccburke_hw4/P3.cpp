#include <cmath>
#include <iostream>
#include <mpi.h>
#include <chrono>

double f(double x) {
    return log(x) - (1.0 / 8.0) * pow(x, 2);
}

double df(double x) {
    return 1.0 / x - x / 4.0;
}

double integrand(double x) {
    return sqrt(1 + pow(df(x), 2));
}

double mpi_length(double a, double b, int num_points, int rank, int size) {
    double interval = (b - a) / num_points;
    double local_sum = 0.0;

    for (int i = rank; i < num_points; i += size) {
        double x = a + (i + 0.5) * interval;
        local_sum += integrand(x);
    }

    double global_sum;
    MPI_Reduce(&local_sum, &global_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    return global_sum * interval;
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <num_points>" << std::endl;
        return 1;
    }

    int num_points = std::stoi(argv[1]);
    double a = 1.0;
    double b = 6.0;

    // Initialize MPI
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Start timer
    MPI_Barrier(MPI_COMM_WORLD);
    double start_time = MPI_Wtime();

    // Compute the length using MPI
    double result = mpi_length(a, b, num_points, rank, size);

    // Stop timer
    MPI_Barrier(MPI_COMM_WORLD);
    double end_time = MPI_Wtime();

    if (rank == 0) {
        double analytical_length = 35.0 / 8.0 + log(6);
        double error = abs(analytical_length - result);
        double elapsed = end_time - start_time;

        std::cout << "Analytical Length: " << analytical_length << std::endl;
        std::cout << "Numerical Length: " << result << std::endl;
        std::cout << "Error: " << error << std::endl;
        std::cout << "Elapsed Time: " << elapsed << "s" << std::endl;
    }

    // Finalize MPI
    MPI_Finalize();

    return 0;
}
