#include <mpi.h>
#include <typeinfo>
#include <iostream>

// Writing template function using point-to-point communication & implementing broadcast
template <typename T>
void my_broadcast(T* data, int count, int root, MPI_Comm comm) {
    int size, rank;
    MPI_Comm_size(comm, &size);
    MPI_Comm_rank(comm, &rank);

    MPI_Datatype datatype;

    if (typeid(T) == typeid(int))
        datatype = MPI_INT;
    else if (typeid(T) == typeid(float))
        datatype = MPI_FLOAT;
    else if (typeid(T) == typeid(double))
        datatype = MPI_DOUBLE;
    else if (typeid(T) == typeid(char))
        datatype = MPI_CHAR;
    else
        // Include additional types as necessary...
        throw std::runtime_error("Unsupported data type");

    if (rank == root) {
        // If we are the root process, send our data to everyone
        for (int i = 0; i < size; i++) {
            if (i != root) {
                MPI_Send(data, count, datatype, i, 0, comm);
            }
        }
    } else {
        // If we are a receiver process, receive the data from the root
        MPI_Recv(data, count, datatype, root, 0, comm, MPI_STATUS_IGNORE);
    }
}

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Define the number of iterations and the root process
    int iterations = 10;
    int root = 0;

    for (int i = 0; i <= 27; i++) {
        long long int data_size = (1 << i);
        char* data = new char[data_size];

        // Time my_broadcast
        MPI_Barrier(MPI_COMM_WORLD);
        double start_time = MPI_Wtime();
        for (int j = 0; j < iterations; j++) {
            my_broadcast(data, data_size, root, MPI_COMM_WORLD);
        }
        double end_time = MPI_Wtime();
        double my_bcast_time = (end_time - start_time) / iterations;

        // Time MPI_Bcast
        MPI_Barrier(MPI_COMM_WORLD);
        start_time = MPI_Wtime();
        for (int j = 0; j < iterations; j++) {
            MPI_Bcast(data, data_size, MPI_CHAR, root, MPI_COMM_WORLD);
        }
        end_time = MPI_Wtime();
        double mpi_bcast_time = (end_time - start_time) / iterations;

        if (rank == root) {
            std::cout << data_size << " " << data_size / my_bcast_time << " " << data_size / mpi_bcast_time << "\n";

        }

        delete[] data;
    }

    MPI_Finalize();
    return 0;
}
