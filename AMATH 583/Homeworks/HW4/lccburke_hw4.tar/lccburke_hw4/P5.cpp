#include <thread>
#include <mutex>
#include <queue>
#include <vector>
#include <condition_variable>
#include <iostream>

// Mutex for thread-safe output
std::mutex mtx;

void safe_cout(std::string msg) {
    std::lock_guard<std::mutex> lock(mtx);
    std::cout << msg << std::endl;
}

class Building;

class Person {
public:
    int id;
    int source;
    int destination;

    Person(int id, int source, int destination) 
    : id(id), source(source), destination(destination) {}

    void call_elevator(Building& building);

    void operator()() {
        std::cout << "Person " << id << " wants to go from floor " << source << " to floor " << destination << std::endl;
    }
};

class Elevator {
public:
    int id;
    int current_floor;
    int direction;
    std::priority_queue<int> floor_queue;

    Elevator(int id) : id(id), current_floor(0), direction(0) {}

    void operate(Building& building);
};

class Building {
public:
    std::vector<std::unique_ptr<Person>> people;
    std::vector<std::unique_ptr<Elevator>> elevators;
    std::mutex mtx;
    std::condition_variable cv;

    Building(int num_people, int num_elevators);
    void request_elevator(int person_id, int source_floor, int destination_floor);
    void dispatch_elevator(int elevator_id, int floor);
    bool all_people_serviced();
    void init();
};

Building::Building(int num_people, int num_elevators) {
    for (int i = 0; i < num_people; i++) {
        int source = rand() % 20;
        int destination;
        do {
            destination = rand() % 20;
        } while (destination == source);

        people.push_back(std::make_unique<Person>(i, source, destination));
    }

    for (int i = 0; i < num_elevators; i++) {
        elevators.push_back(std::make_unique<Elevator>(i));
    }
}

void Building::request_elevator(int person_id, int source_floor, int destination_floor) {
    std::lock_guard<std::mutex> lock(mtx);
}

void Building::dispatch_elevator(int elevator_id, int floor) {
    std::lock_guard<std::mutex> lock(mtx);
    
    // Add the floor to the elevator's queue
    elevators[elevator_id]->floor_queue.push(floor);

    safe_cout("Dispatched elevator " + std::to_string(elevator_id) + " to floor " + std::to_string(floor));
}

void Building::init() {
    for (auto& person : people) {
        std::thread t(&Person::call_elevator, person.get(), std::ref(*this));
        t.detach();
    }

    for (auto& elevator : elevators) {
        std::thread t(&Elevator::operate, elevator.get(), std::ref(*this));
        t.detach();
    }
}

bool Building::all_people_serviced() {
    for (auto& person : people) {
        if (person->source != person->destination) {
            return false;  // There's at least one person who hasn't been serviced yet
        }
    }
    return true;  // All people have been serviced
}

void Person::call_elevator(Building& building) {
    building.request_elevator(id, source, destination);
}

void Elevator::operate(Building& building) {
    while (!building.all_people_serviced() || !floor_queue.empty()) {
        std::lock_guard<std::mutex> lock(building.mtx);

        if (!floor_queue.empty()) {
            int next_floor = floor_queue.top(); // Get the next floor from the queue
            floor_queue.pop(); // Remove the next floor from the queue

            safe_cout("Elevator " + std::to_string(id) + " moving from floor " + std::to_string(current_floor) + " to floor " + std::to_string(next_floor));
            current_floor = next_floor; // Update the current floor
        }
    }
}

int main() {
    Building building(0, 1); // Create a Building with one Elevator and no People

    building.dispatch_elevator(0, 2);
    building.dispatch_elevator(0, 1);
    building.dispatch_elevator(0, 3);

    std::this_thread::sleep_for(std::chrono::seconds(10)); // Wait for the elevator to visit all the floors

    safe_cout("Elevator " + std::to_string(building.elevators[0]->id) + " is on floor " + std::to_string(building.elevators[0]->current_floor));

    return 0;
}
