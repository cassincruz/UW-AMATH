# AMATH 583 HW 4

## Problem 1

### Files
- File: P1.cpp
- Output: IObandwidth.txt
- Plot: IObandwidth_plot.png

## Problem 2
To begin, we will find the length of the graph $f(x) = \ln (x) - \frac{1}{8} x^2$ on $[1,6]$ analytically. We have 

$$\begin{align} 
L &= \int_1^6 \sqrt{1 + \left(\frac{1}{x} - \frac{1}{4} x \right)^2} dx \\
&= int_1^6 \sqrt{1 + \frac{1}{x^2} - \frac{1}{2x} + \frac{1}{16} x^2} dx \\
&= \frac{35}{8} + \ln(6) \\
&\approx 6.1668
 \end{align}$$

### Files
- P2.cpp
- P2_plot.png

## Problem 3

### Files
- P3.cpp
- 

## Problem 5

