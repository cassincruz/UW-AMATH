#include <iostream>
#include <fstream>
#include <vector>
#include <random>
#include <chrono>

int writeMatrix (int n) { // Writes a random n x n matrix and prints the write time
    // Create a random number generator
    std::mt19937_64 rng(std::random_device{}());
    std::uniform_real_distribution<double> dist(0.0, 1.0);

    // Create the matrix and fill it with random values
    std::vector<double> matrix(n * n);
    for (int i = 0; i < n * n; i++)
    {
        matrix[i] = dist(rng);
    }
    
    // Timing write speed
    auto start = chrono::high_resolution_clock::now();
    std::string filename = "matrix_" + std::to_string(n) + ".bin";
    std::ofstream outfile(filename, std::ios::out | std::ios::binary);
    if (outfile.is_open())
    {
        outfile.write(reinterpret_cast<const char *>(matrix.data()), sizeof(double) * n * n);
        outfile.close();
        std::cout << "Saved matrix to " << filename << std::endl;
    }
    else
    {
        std::cerr << "Failed to open file: " << filename << std::endl;
        return 1;
    }
    auto end = chrono::high_resolution_clock::now();

    return 0;
}

int readMatrix (int n, const std::string& filename) { // Reads an n x n matrix and prints the read time
    // Open binary file for reading
    std::ifstream  input(filename, std::ios::binary);
    if (!input) {
        std::cout << "Error: cannot open file." << std::endl;
        return 1;
    }

    // Create a vector to store the matrix
    std::vector<double> matrix(n * n);

    // Read the binary data into the vector
    input.read(reinterpret_cast<char *>(matrix.data()), sizeof(double) * matrix.size());

    // Check if read was successful
    if (!input)
    {
        std::cerr << "Error: could not read file" << std::endl;
        return 1;
    }

    // Print the matrix elements
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            std::cout << matrix[i * n + j] << " ";
        }
        std::cout << std::endl;
    }
}

int main() {
    std::vector<int> ns = {32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384};
    for (int n : ns) {
        std::string filename = "matrix_" + std::to_string(n) + ".bin";
        
    }
}